package controllers;


import java.io.IOException; 
import java.util.List;
import java.util.SortedMap;
import java.util.TreeMap;

import models.DecisionProcedure;
import models.DecisionProperties;
import models.DecisionResult;
import models.Language;
import models.Sequent;
import models.SequentCalculus;
import utils.FileUtilsInternal;
import utils.MultiMap;
import utils.StringUtils;

public class CmdApplication {


	public static void main(String[] args) throws IOException {
		//new StaticApplication(new File("")).application(); 
		if (args.length == 0) {
			printHelp();
			return;
		}
		String path = args[0];
		runFromFile(path);
	} 

	private static void printHelp() throws IOException {
		System.out.println("Welcome to gen2sat");
		System.out.println("Usage: java -jar gen2sat.jar <path to file> <number of runs>");
		System.out.println("path to file: the path to the file that contains the problem description");
		System.out.println("An example of such a file can be found here: http://delta-tomcat-vm.cs.tau.ac.il:40123/gen2sat/assets/LK.txt ");
		System.out.println("number of runs is optional");
	}

	private static void runFromFile(String path) throws IOException {
		String stringOfFile = FileUtilsInternal.getFileAsString(path);
		String stringOfFileNoComments = StringUtils.deleteAllLinesStartingWith(stringOfFile, "#");
		List<String> requiredTestsStrings = StringUtils.splitAndTrimToList(stringOfFileNoComments, "-----");
		for (String testString : requiredTestsStrings) {
			run(testString);
		}
	}



private static void run(String testString) {
	MultiMap<String, String> lines = StringUtils.getLinesAsMultiMap(testString, ":");
	DecisionProperties decisionProperties = DecisionProperties.makeInstance(testString);
	Language l = Language.makeInstance(lines.getSome(""), lines.getSome("connectives"), lines.getSome("nextOperators"));
	String rules = "";
	if (lines.containsKey("rule")) {
		for (String rule : lines.getAll("rule")) {
			rules += "\n" + rule;
		}
	}
	SequentCalculus G = SequentCalculus.makeInstance(rules, l, lines.getSome("analyticity"));
	DecisionProcedure d = new DecisionProcedure(G, decisionProperties);
	SortedMap<String, Sequent> inputSequents = getSequents(l, testString);
	for (String name : inputSequents.keySet()) {
		long startTime = System.currentTimeMillis();
		DecisionResult decisionResult = decideOnSequent(l, G, d, inputSequents.get(name));
		long endTime = System.currentTimeMillis();
		String provableOrUnprovableOrTimeout = "timeout";
		if (!decisionResult.isTimeoutExceeded()) {
			if (decisionResult.isProvable()) {
				provableOrUnprovableOrTimeout = "provable";
			} else {
				provableOrUnprovableOrTimeout = "unprovable";
			}
		}
		String line = (!StringUtils.isEmpty(name)  ? name  + ";" : "") + provableOrUnprovableOrTimeout + ";" +  (endTime - startTime) + "ms"; 
		System.out.println(line);
		if ((decisionResult.isProvable() && decisionProperties.includeDetails())) {
			System.out.println("There is a proof that uses only these rules: " + 
					decisionResult.getMinimalSetOfRules().toString());
		}
		if (!decisionResult.isProvable() && decisionProperties.includeDetails()) {
			System.out.println("Countermodel: " + 
					decisionResult.getCounterModel().toString());
		}
	}

		
	}

private static SortedMap<String, Sequent> getSequents(Language l, String stringOfSystem) {
	SortedMap<String,Sequent> result = new TreeMap<String, Sequent>();
	List<String> lines = StringUtils.splitAndTrimToList(stringOfSystem, "\n");
	for (String line: lines) {
		String type = line.substring(0, line.indexOf(':'));
		String value = line.substring(line.indexOf(':')+1);
		type = type.trim();
		value = value.trim();
		if (type.contains("inputSequent") || type.contains("sequent")) {
			String name = "";
			if (type.contains("-")) {
				name = type.substring(type.indexOf('-')+1, type.length());
			}
			name = name.trim();
			result.put(name, Sequent.makeInstance(value, l));
		}
	}
	return result;
}

private static DecisionResult decideOnSequent(Language l, SequentCalculus G, DecisionProcedure d, Sequent s)  {
	DecisionResult decisionResult = null;
	decisionResult = d.decide(s);
	return decisionResult;
}


}
