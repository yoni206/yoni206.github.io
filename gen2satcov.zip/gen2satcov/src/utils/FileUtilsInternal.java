package utils;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

import org.apache.commons.io.FileUtils;


public class FileUtilsInternal {
	public static String getFileAsString(String absolutePath) throws IOException {
		File f = new File(absolutePath);
		String str = FileUtils.readFileToString(f);
//		InputStream in = FileUtilsInternal.class.getResourceAsStream(relativePath);
//		String str = fromStream(in);
		return str;
	}	
	
}
