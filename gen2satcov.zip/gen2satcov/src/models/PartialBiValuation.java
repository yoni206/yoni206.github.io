package models;

import java.util.Map;
import java.util.Set;

public class PartialBiValuation {
	Map<Formula, Boolean> map;

	public PartialBiValuation(Map<Formula, Boolean> map) {
		super();
		this.map = map;
	}


	
	
	
	@Override
	public String toString() {
		String result = map.toString();
		result = result.substring(1, result.length()-1);
		return result;
	}
	
	
	
}
