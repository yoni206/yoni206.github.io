package models;

import java.util.LinkedHashSet; 
import java.util.Set;

import utils.MultiMap;

public class DecisionResult {
	
	private boolean provable;
	private Set<Rule> minimalSetOfRules;
	private PartialBiValuation counterModel;
	private boolean timeoutExceeded;
	
	/**
	 * to be called when the sequent is provable
	 * @param satInstance
	 * @param semanticConstraintsHoldToRules 
	 */
	private DecisionResult(SatInstance<Formula> explanation, MultiMap<SatClause<Formula>, Rule> semanticConstraintsHoldToRules) {
		this.provable = true;
		minimalSetOfRules = getSetOfRules(explanation, semanticConstraintsHoldToRules);
		this.counterModel = null;
		this.timeoutExceeded = false;
	}
	
	private Set<Rule> getSetOfRules(SatInstance<Formula> explanation,
			MultiMap<SatClause<Formula>, Rule> semanticConstraintsHoldToRules) {
		Set<Rule> result = new LinkedHashSet<Rule>();
		if (explanation != null && explanation.getSetOfClauses() != null) {
			for (SatClause<Formula> clause : explanation.getSetOfClauses()) {
				if (semanticConstraintsHoldToRules.containsKey(clause)) {
					result.addAll(semanticConstraintsHoldToRules.getAll(clause));
				}
			}
		}
		return result;
	}

	/**
	 * to be called when the sequent is unprovable
	 * @param counterModel
	 */
	private DecisionResult(PartialBiValuation counterModel) {
		this.provable = false;
		this.minimalSetOfRules = null;
		this.counterModel = counterModel;
		this.timeoutExceeded = false;
	}
	
	/**
	 * to be called when there was a timeout
	 */
	private DecisionResult() {
		this.provable = true;
		minimalSetOfRules = null;
		this.counterModel = null;
		this.timeoutExceeded = true;
	}

	public boolean isProvable() {
		return provable;
	}


	public PartialBiValuation getCounterModel() {
		return counterModel;
	}
	
	public static DecisionResult createProvableDecisionResult(SatInstance<Formula> satInstance, MultiMap<SatClause<Formula>, Rule> semanticConstraintsHoldToRules) {
		return new DecisionResult(satInstance, semanticConstraintsHoldToRules);
	}
	
	public static DecisionResult createUnprovableDecisionResult(PartialBiValuation counterModel) {
		return new DecisionResult(counterModel);
	}
	
	public static DecisionResult createTimeoutDecisionResult() {
		return new DecisionResult();
	}

	public boolean isTimeoutExceeded() {
		return timeoutExceeded;
	}

	public Set<Rule> getMinimalSetOfRules() {
		return minimalSetOfRules;
	}

	@Override
	public String toString() {
		return "DecisionResult [provable=" + provable + ", minimalSetOfRules="
				+ minimalSetOfRules + ", counterModel=" + counterModel
				+ ", timeoutExceeded=" + timeoutExceeded + "]";
	}


}
