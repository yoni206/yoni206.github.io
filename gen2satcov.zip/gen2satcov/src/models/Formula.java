package models;

import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.Stack;



public abstract class Formula implements Comparable<Formula> {
	
	public Formula() {
		
	}
	



	public Formula copyFormula(Formula formula) {
		if (formula instanceof AtomicFormula) {
			AtomicFormula atomicFormula = (AtomicFormula)formula;
			return new AtomicFormula(atomicFormula.getSymbol());
		} else {
			CompoundFormula compundFormula = (CompoundFormula) formula;
			return new CompoundFormula(compundFormula.getConnective(), compundFormula.getImmediateSubformulas());
		}
	}





	public static Formula makeInstance(String str, Language L) {
		str = str.replace(" ", ""); 
		Formula result = null;
		if (L.isStringAnAtomicFormula(str)) {
			result = AtomicFormula.makeInstance(str);
		} else {
			result = CompoundFormula.makeInstance(str, L);
		}
		if (result == null) {
			throw new NullPointerException();
		} else {
			return result;
		}
	}





	public Set<Formula> getLocalFormulas(Set<PropositionalConnective> unaryConnectives) {
		//Set<Formula> result = getLocalFormulasNoRecursion(unaryConnectives);
		Set<Formula> result = new LinkedHashSet<Formula>();
		getLocalFormulasRecursive(unaryConnectives, result);
		return result;
	}

	public void getLocalFormulasRecursive(Set<PropositionalConnective> unaryConnectives, Set<Formula> result) {
		result.add(this);
		if (! (this instanceof AtomicFormula)) {
			CompoundFormula cThis = (CompoundFormula) this;
			PropositionalConnective mainConnective = cThis.getConnective();
			if (mainConnective instanceof NextOperator) {
				NextOperator nextOperator = (NextOperator) mainConnective;
				Set<Formula> resultBeforePrefix = new LinkedHashSet<Formula>();
				cThis.getImmediateSubformulas().get(0).getLocalFormulasRecursive(unaryConnectives, resultBeforePrefix);
				result.addAll(nextOperator.addToAllFormulas(resultBeforePrefix));
			}
			else {
				for (Formula immediateSubformula : cThis.getImmediateSubformulas()) {
					for (PropositionalConnective unaryConnective : unaryConnectives) {
						Formula formulaToAdd = new CompoundFormula(unaryConnective, immediateSubformula);
						result.add(formulaToAdd);
					}
				}
				for (Formula immediateSubformula : cThis.getImmediateSubformulas()) {
					immediateSubformula.getLocalFormulasRecursive(unaryConnectives, result);
				}
			}
		}

	}
	
	public boolean hasPrefix() {
		return this.getMaximalPrefix().getLength() != 0;
	}
	
	
	public Formula getBody() {
		return this.trim(this.getMaximalPrefix());
	}
	




	public static Set<Formula> getSubformulasOfASet(Set<Formula> formulas, Set<PropositionalConnective> unaryConnectives) {
		Set<Formula> result = new LinkedHashSet<Formula>();
		for (Formula formula: formulas) {
			result.addAll(formula.getSubformulas(unaryConnectives));
		}
		return result;
	}





	public Set<Formula> getSubformulas(Set<PropositionalConnective> unaryConnectives) {
		Set<Formula> result = new LinkedHashSet<Formula>();
		result.add(this);
		if (! (this instanceof AtomicFormula)) {
			CompoundFormula compoundFormula = (CompoundFormula)this;
			for (Formula formula : compoundFormula.getImmediateSubformulas()) {
				for (Formula subformula: formula.getSubformulas(unaryConnectives)) { 
					result.add(subformula);
					for (PropositionalConnective unaryConnective : unaryConnectives) {
						Formula unariedFormula = new CompoundFormula(unaryConnective, subformula);
						result.add(unariedFormula);
						result.addAll(formula.getSubformulas(unaryConnectives));
					}
				}
			}
		}  
		return result;
	}





	@Override
	public int compareTo(Formula o) {
		return this.toString().compareTo(o.toString());
	}





	public Formula prefixBy(Prefix prefix) {
		if (prefix.isTheEmptyPrefix()) {
			return this;
		} else {			
			Formula result = copyFormula(this);
			for (int i=prefix.getLength()-1; i>=0; i--) {
				result = new CompoundFormula(prefix.getOperator(i), result);
			}
			return result;
		}
	}



	// if prefix is not a prefix of this formula, then we return this formula
	public Formula trim(Prefix prefix) {
			if (this instanceof AtomicFormula) {
				return this;
			} else {
				CompoundFormula thisCompound = (CompoundFormula)this;
				if (thisCompound.hasPrefix(prefix)) {
					if (prefix.isTheEmptyPrefix()) {
						return this;
					} else {
						return thisCompound.getImmediateSubformulas().get(0).trim(prefix.getSubPrefix(1));
					}
				} else {
					return this;
				}
			}
		}





	public Prefix getMaximalPrefix() {
		if (this instanceof AtomicFormula) {
			return new Prefix(); 
		} else {
			return ((CompoundFormula)this).getMaximalPrefix();
		}
	}





	public boolean hasPrefix(Prefix prefix) {
		if (prefix.isTheEmptyPrefix()) {
			return true;
		} else {
			if (this instanceof AtomicFormula) {
				return false;
			} else {				
				return ((CompoundFormula)this).hasPrefix(prefix);
			}
		}
	}
	


	
}
