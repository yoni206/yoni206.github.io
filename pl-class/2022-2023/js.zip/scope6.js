function block() {
  if (true) {
    var j = 0;
  }
  console.log(j)
}

block()
console.log(j) 
