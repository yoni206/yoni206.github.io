function f(x) {
  return this.a + x;
}

o1 = {a : 1};
o2 = {a : 2};

console.log(f.call(o1, 5));
console.log(f.apply(o2, [5]));
