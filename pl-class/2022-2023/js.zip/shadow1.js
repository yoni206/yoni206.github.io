var scope = "global";
function checkscope() {
  var scope = "local"
  console.log(scope);
}
checkscope()
console.log(scope)
