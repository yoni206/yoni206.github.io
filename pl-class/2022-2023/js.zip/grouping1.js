var x = 3;
x;
{ var x = 4 ; x } 
x;
