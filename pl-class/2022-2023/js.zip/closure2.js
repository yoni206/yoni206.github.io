function f(x) {
  function g(y) { return x + y; };
  return g ; 
}

var h = f(3);
var j = f(4);
var z = h(5);
var w = j(5);

console.log(z)
console.log(w)
