function f(x) {
  var y = x;
  return function (z){y += z; return y;} 
}
var h = f(5); 
console.log(h(3));
