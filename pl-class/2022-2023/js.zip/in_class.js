function f () {
  function g() {
    x = 2
  }
  g()
  return 1
}
f()
console.log(x)
