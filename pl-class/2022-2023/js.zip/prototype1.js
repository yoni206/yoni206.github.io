function Circle(x,y,r) {
  this.x = x; 
  this.y = y;
  this.r = r;
}

var c = new Circle(0, 0, 1);

Circle.prototype.pi = 3.14; // shared by all circles, defined after c

Circle.prototype.heikef = function () {return 2 * this.pi * this.r;}

Circle.prototype.shetach = function() {return this.pi * this.r * this.r;}

var a = c.shetach();
var b = c.heikef();

console.log(a)
console.log(b)
