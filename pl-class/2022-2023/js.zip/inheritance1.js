function Complex(x, y) {
  this.x = x;
  this.y = y;;
}
Complex.prototype.sum = function() {return this.x + this.y;}

function AdvancedComplex(x,y) {
  this.x = x;
  this.y = y;
}

AdvancedComplex.prototype = new Complex(0,0);

AdvancedComplex.prototype.swap = function() {
  var tmp = this.x;
  this.x = this.y;
  this.y = this.x;
}

var c = new Complex(1,2);
var ac = new AdvancedComplex(1,2);

console.log(c.sum());
console.log(ac.sum());
ac.swap();
// c.swap();
