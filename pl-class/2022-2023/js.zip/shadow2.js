var scope = "global";
function checkscope() {
  scope = "local"
  console.log(scope);
}
checkscope()
console.log(scope)
