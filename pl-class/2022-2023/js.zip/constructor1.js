function Rectangle(w,h) {
  this.width = w;
  this.height = h;
}

var rect1 = new Rectangle(1,2);
var rect2 = new Rectangle(1,4);

console.log(rect1)
console.log(rect2)
