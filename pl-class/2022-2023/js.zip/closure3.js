var myObject = function () {
  var value = 0;
  return {
    increment: function() {
      value += 1;
    },
    getValue: function () {
      return value;
    }
  };
}();

console.log(myObject.getValue())
console.log(myObject.getValue())
console.log(myObject.getValue())
console.log(myObject.value)
