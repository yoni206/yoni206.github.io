type var = string;;
type state = var -> ?? ;;
type n = int -> ?? ;;

type a = ??

type b = ??

type stm = ???