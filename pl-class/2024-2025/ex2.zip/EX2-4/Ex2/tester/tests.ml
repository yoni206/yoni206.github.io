(* Tests *)
let test_aritmetic_semantic () =
  let s = default_state in
  assert (aritmetic_semantic (Num (fun _ -> 5)) s = 5);
  assert (aritmetic_semantic (Add (Num (fun _ -> 3), Num (fun _ -> 2))) s = 5);
  assert (aritmetic_semantic (Mult (Num (fun _ -> 4), Num (fun _ -> 2))) s = 8);
  assert (aritmetic_semantic (Sub (Num (fun _ -> 5), Num (fun _ -> 3))) s = 2);
  ();;

let test_boolean_semantic () =
  let s = default_state in
  assert (boolean_semantic TT s = true);
  assert (boolean_semantic FF s = false);
  assert (boolean_semantic (Neg TT) s = false);
  assert (boolean_semantic (Beq (TT, FF)) s = false);
  assert (boolean_semantic (Aeq (Num (fun _ -> 3), Num (fun _ -> 3))) s = true);
  assert (boolean_semantic (And (TT, FF)) s = false);
  ();;

let test_nos () =
  let s = default_state in
  let s_new = nos (Ass ("x", Num (fun _ -> 5)), s) in
  assert (s_new "x" = 5);
  let s_new = nos (Skip, s) in
  assert (s_new "x" = 0);
  let s_new = nos (Comp (Ass ("x", Num (fun _ -> 5)), Ass ("y", Num (fun _ -> 10))), s) in
  assert (s_new "x" = 5);
  assert (s_new "y" = 10);
  let s_new = nos (If (TT, Ass ("x", Num (fun _ -> 5)), Ass ("x", Num (fun _ -> 10))), s) in
  assert (s_new "x" = 5);
  let s_new = nos (If (FF, Ass ("x", Num (fun _ -> 5)), Ass ("x", Num (fun _ -> 10))), s) in
  assert (s_new "x" = 10);
  let s_new = nos (While (Aeq (Var "x", Num (fun _ -> 0)), Ass ("x", Num (fun _ -> 1))), s) in
  assert (s_new "x" = 1);
  ();;

let test_if_ass () =
  let s = default_state in 
  
  let s_new = nos (If_Ass ("a", Num (fun _ -> 10), Ass ("b", Num (fun _ -> 20)), Ass ("b", Num (fun _ -> 30))), s) in
  assert (s_new "a" = 10);
  assert (s_new "b" = 20);
  
  let s_new = nos (If_Ass ("a", Num (fun _ -> 0), Ass ("b", Num (fun _ -> 20)), Ass ("b", Num (fun _ -> 30))), s) in
  assert (s_new "a" = 0);
  assert (s_new "b" = 30);
  
  let s_new = nos (If_Ass ("c", Num (fun _ -> 0), Ass ("d", Num (fun _ -> 50)), Ass ("d", Num (fun _ -> 40))), s) in
  assert (s_new "c" = 0);
  assert (s_new "d" = 40);
  
  let s_new = nos (If_Ass ("c", Num (fun _ -> 1), Ass ("d", Num (fun _ -> 50)), Ass ("d", Num (fun _ -> 40))), s) in
  assert (s_new "c" = 1);
  assert (s_new "d" = 50);
  ();;

let test_repeat () =
  let s = default_state in
  let s_new = nos (Ass ("x", Num (fun _ -> 0)), s) in
  let s_new = nos (Repeat (Ass ("x", Add (Var "x", Num (fun _ -> 1))), Aeq (Var "x", Num (fun _ -> 5))), s) in
  assert (s_new "x" = 5);
  ();;

let () =
  test_aritmetic_semantic ();
  test_boolean_semantic ();
  test_nos ();
  test_if_ass ();
  test_repeat ();
  print_endline "All tests passed!";;