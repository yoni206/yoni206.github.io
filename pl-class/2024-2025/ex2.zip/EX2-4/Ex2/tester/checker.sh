#!/bin/bash

# Concatenate files
cat ../ast.ml ../semantics.ml tests.ml > combined.ml

# Compile the combined file
ocamlc -o combined combined.ml

# Check if compilation was successful
if [ $? -eq 0 ]; then
    # Run the compiled program
    ./combined

    # Check if the tests passed
    if [ $? -eq 0 ]; then
        echo "All tests passed!"
    else
        echo "Some tests failed."
        exit 1
    fi
else
    echo "Compilation failed."
    exit 1
fi
