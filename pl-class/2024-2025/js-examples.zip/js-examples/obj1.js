var book = new Object();
book.title = "bla bla";
book.numOfChapters = 3;
book.title = "blu blu";
console.log("title: " + book.title)
