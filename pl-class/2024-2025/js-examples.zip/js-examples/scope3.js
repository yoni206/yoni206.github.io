function f(x) {
  var y = 3;
  function g(z) { return y+z;}; 
  return g(x);
}
var x = 1; 
var y = 2; 
var result = f(x) + y;
console.log(result)
