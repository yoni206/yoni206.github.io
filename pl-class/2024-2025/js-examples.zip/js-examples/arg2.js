function check(x, y=2) {
  var actual = arguments.length
  var expected = arguments.callee.length
  console.log(actual)
  console.log(expected)
  console.log("------")
}
check()
check(1)
check(1,2)
check(1,2,3)


console.log(check(5))
