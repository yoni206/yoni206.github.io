var book = new Object();
book.title = "bla bla";
book.numOfChapters = 3;
book.title = "blu blu";
for (var name in book) {
  console.log("name: " + name);
  console.log("value: " + book[name]);
  console.log("---------------");
}
