function Rectangle(w,h) {
  this.width = w;
  this.height = h;
}

var rect1 = Rectangle(1,2);
var rect2 = Rectangle(1,4);

console.log(Rectangle.width)
console.log(rect2)
