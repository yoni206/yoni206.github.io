function block() {
  if (true) {
    j = 0;
  }
  console.log(j)
}

block()
console.log(j) 
