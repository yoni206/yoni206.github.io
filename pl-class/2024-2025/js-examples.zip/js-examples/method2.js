var foo = function() {
  return this.a;
}

o1 = {a: 1};
o2 = {a: 2};

o1.f = foo;
o2.f = foo;

console.log(foo());
console.log(o1.f());
console.log(o2.f());
