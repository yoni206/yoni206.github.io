function f() { 
  console.log(scope);
  scope = "local"; 
  console.log(scope);
}
f()
