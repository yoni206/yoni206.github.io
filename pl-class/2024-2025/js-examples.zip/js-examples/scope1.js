var f = function(){ 
  var a = g(); 
  function g() { return 1;}; 
  function g() { return 2;}; 
  var g = function() { return 3;} 
  return a;
}
var result = f();
console.log(result)
