function f() {
  x = 5;
  var y=5;
}
f()
console.log(x);
console.log(y);
