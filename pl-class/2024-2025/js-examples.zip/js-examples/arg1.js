function f() {
  if (arguments.length <= 1) {
    return 0;
  } else {
    var result = 1;
    for (var i=0; i < arguments.length; i++) {
      result = result * arguments[i];
    }
    return result;
  }
}
console.log(f())
console.log(f(1))
console.log(f(1,2))
console.log(f(1,2,3))
console.log(f(1,2,30))
