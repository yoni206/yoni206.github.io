(* Tests for sum_list function *)
let test_sum_list1 = sum_list [1; 2; 3; 4; 5];;
print_int test_sum_list1;;
print_newline ();;

let test_sum_list2 = sum_list [];;
print_int test_sum_list2;;
print_newline ();;

let test_sum_list3 = sum_list [-1; -2; -3; 0; 3; 2; 1];;
print_int test_sum_list3;;
print_newline ();;

(* Tests for compress function *)
let test_compress1 = compress ["a"; "a"; "b"; "b"; "c"; "c"; "c"; "a"; "a"];;
print_string (String.concat " " test_compress1);;
print_newline ();;

let test_compress2 = compress ["hello"; "hello"; "world"];;
print_string (String.concat " " test_compress2);;
print_newline ();;

let test_compress3 = compress [];;
print_string (String.concat " " test_compress3);;
print_newline ();;
