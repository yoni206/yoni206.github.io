(* Test 1: Basic test with simple numbers *)
let test1 = arithmetic_hell [1; 2; 3];;
print_int test1;;
print_newline ();;

(* Test 2: Test with same numbers - should result in more combinations *)
let test2 = arithmetic_hell [2; 2; 2];;
print_int test2;;
print_newline ();;

(* Test 3: Test with a single number *)
let test3 = arithmetic_hell [5];;
print_int test3;;
print_newline ();;

(* Test 4: Test with no numbers *)
let test4 = arithmetic_hell [];;
print_int test4;;
print_newline ();;


(* Test 4: Test with no numbers *)
let test5 = arithmetic_hell [8;5;3;1;15];;
print_int test5;;
print_newline ();;

(* Test 4: Test with no numbers *)
let test5 = arithmetic_hell [7;3;4;2;27];;
print_int test5;;
print_newline ();;