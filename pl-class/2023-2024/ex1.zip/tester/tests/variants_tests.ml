(* Tests for area function *)
let test_area_circle = area (Circle 5.0);;
print_float test_area_circle;;
print_newline ();;

let test_area_square = area (Square 4.0);;
print_float test_area_square;;
print_newline ();;

let test_area_rectangle = area (Rectangle (3.0, 2.0));;
print_float test_area_rectangle;;
print_newline ();;

(* Tests for total_area function *)
let test_total_area_mixed = total_area [Circle 1.0; Square 2.0; Rectangle (3.0, 4.0)];;
print_float test_total_area_mixed;;
print_newline ();;

let test_total_area_empty = total_area [];;
print_float test_total_area_empty;;
print_newline ();;  (* Corrected line *)
