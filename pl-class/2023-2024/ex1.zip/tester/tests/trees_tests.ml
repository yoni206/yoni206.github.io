(* Function to convert a binary tree to a string for testing purposes *)
let rec string_of_tree = function
    | Empty -> "()"
    | Node (value, left, right) ->
        (string_of_int value) ^ "(" ^ (string_of_tree left) ^ "," ^ (string_of_tree right) ^ ")"

(* Tests for construct function *)
let test_construct1 = construct [3; 2; 5; 7; 1];;
print_endline (string_of_tree test_construct1);;

let test_construct2 = construct [5; 3; 8; 1; 4; 7; 9];;
print_endline (string_of_tree test_construct2);;

let test_construct3 = construct [];;
print_endline (string_of_tree test_construct3);;
