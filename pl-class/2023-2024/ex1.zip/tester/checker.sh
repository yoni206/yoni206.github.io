#!/bin/bash

# Define colors
GREEN='\033[0;32m'
RED='\033[0;31m'
NC='\033[0m' # No Color

# Remove existing Results directory if it exists
[ -d Results ] && rm -rf Results
mkdir Results

# Function to process each .ml file
process_file() {
    local ml_file=$1
    local test_file="tests/$2"
    local true_answers_file="true_answers/$3"
    local result_file="Results/${ml_file%.*}_results.txt"

    echo "Processing $ml_file..."
    cat $ml_file > temp.ml
    cat $test_file >> temp.ml
    ocaml temp.ml > $result_file

    # Compare results with true answers
    local line_num=1
    while IFS= read -r expected_line; do
        actual_line=$(sed -n "${line_num}p" $result_file)
        if [ "$actual_line" = "$expected_line" ]; then
            echo -e "${GREEN}Test $line_num: PASSED${NC}"
        else
            echo -e "${RED}Test $line_num: FAILED. Expected: '$expected_line', Got: '$actual_line'${NC}"
        fi
        ((line_num++))
    done < $true_answers_file
}

# Process each file with its corresponding tests and true answers
process_file lists.ml lists_tests.ml lists_true_answers.txt
process_file trees.ml trees_tests.ml trees_true_answers.txt
process_file variants.ml variants_tests.ml variants_true_answers.txt
process_file hardquestions.ml hardquestions_tests.ml hardquestions_true_answers.txt

# Clean up
rm temp.ml
echo "Processing complete. Check the Results directory and console for output."
