package models;

import static org.junit.Assert.assertEquals;

import java.util.Set;
import java.util.TreeSet;

import org.junit.Test;

public class FormulaTest {

	Language language = Language.makeInstance("", "AND:2,OR:2,IMPLIES:2,NOT:1", "");
	Formula formula = Formula.makeInstance("A AND (B AND C)", language);
	
	

	
	
	/**
	 * test the "getSubformulas()" method of class Formula.
	 */
	@Test
	public void getSubformulasTest1() {
		Set<Formula> expectedSubformulas = new TreeSet<Formula>();
		expectedSubformulas.add(Formula.makeInstance("A", language));
		expectedSubformulas.add(Formula.makeInstance("B", language));
		expectedSubformulas.add(Formula.makeInstance("C", language));
		expectedSubformulas.add(Formula.makeInstance("B AND C", language));
		expectedSubformulas.add(Formula.makeInstance("A AND (B AND C)", language));
		assertEquals(expectedSubformulas, formula.getSubFormulas());
	}
	

	
	


   
	

	
	
	
	
	

	
	
}



