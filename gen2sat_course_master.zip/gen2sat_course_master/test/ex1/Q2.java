package ex1;

import org.junit.Assert;
import org.junit.Test;

import utils.StringUtils;

public class Q2 {

	@Test
	public void balancedTest() {
		String str1 = "a(bc))";
		boolean result1;
		result1 = StringUtils.balanced(str1);
		Assert.assertTrue(true); //your assertion here
	}
	
}



