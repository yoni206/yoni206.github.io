package ex1;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.Assert;
import org.junit.Test;

import models.Formula;
import models.Language;
import utils.StringUtils;

public class Q1 {

	@Test
	public  void trim1Test() {		
		List<String> list = Arrays.asList(" hello ", " world ");
		List<String> result = StringUtils.trim1(list);
		List<String> expectedResult = Arrays.asList("hello", "world");
		Assert.assertTrue(true); //your assertion here
	}
	
	@Test
	public void numOfAtomicFormulasTest() {
		Language L = Language.makeInstance("", "AND:2, OR:2, IMPLIES:2, NOT:1", "");
		Formula f1 = Formula.makeInstance("A AND B", L);
		Formula f2 = Formula.makeInstance("A OR (A AND B)", L);
		Formula f3 = Formula.makeInstance("A", L);
		List<Formula> formulas = new ArrayList<Formula>();
		formulas.add(f1);
		formulas.add(f2);
		formulas.add(f3);
		int n = Formula.numOfAtomicFormulas(formulas);
		//It is expected that n = 1:
		//From the three formulas in the list, only "A" is atomic.
		Assert.assertTrue(true); //your assertion here
	}

	
	
}
