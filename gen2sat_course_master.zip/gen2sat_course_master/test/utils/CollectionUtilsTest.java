package utils;

import java.util.Set;
import java.util.TreeSet;

import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;

public class CollectionUtilsTest {

	Set<Integer> A,B,C;
	
	/**
	 * This method runs before each test
	 */
	@Before
	public void initiateAllSets() {
		A = new TreeSet<Integer>();
		B = new TreeSet<Integer>();
		C = new TreeSet<Integer>();
	}
	
	/*
	 * Intersection has the right element
	 */
	@Test
	public void intersectionTest1() {
		A.add(1);
		A.add(2);
		A.add(3);
		B.add(3);
		B.add(4);
		B.add(5);
		C = CollectionUtils.intersection(A, B); // C={3}
		assertTrue(C.contains(3));
	}
	
	/*
	 * Intersection does not have an extra element
	 */
	@Test
	public void intersectionTest2() {
		A.add(1);
		A.add(2);
		A.add(3);
		B.add(3);
		B.add(4);
		B.add(5);
		C = CollectionUtils.intersection(A, B); // C={3}
		assertFalse(C.contains(4));
	}

}
